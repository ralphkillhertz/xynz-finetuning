"""
Demos y ejemplos del sistema
"""
# Este archivo puede estar vacío o solo con el docstring