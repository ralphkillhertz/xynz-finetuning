#!/usr/bin/env python3
"""
definitive_numpy_fix.py - Solución definitiva para el problema numpy/OSC

El problema: pythonosc NO acepta tipos numpy (float32, float64)
La solución: Convertir SIEMPRE a float nativo de Python antes de enviar
"""

import os
import shutil
from datetime import datetime


def backup_file(filepath):
    """Crear backup del archivo"""
    if os.path.exists(filepath):
        backup_path = f"{filepath}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(filepath, backup_path)
        print(f"✅ Backup creado: {backup_path}")
        return backup_path
    return None


def fix_spat_osc_bridge():
    """Corregir spat_osc_bridge.py para convertir tipos numpy"""
    
    print("\n🔧 CORRIGIENDO spat_osc_bridge.py")
    print("=" * 60)
    
    # Buscar el archivo
    paths = [
        "trajectory_hub/core/spat_osc_bridge.py",
        "core/spat_osc_bridge.py",
        "spat_osc_bridge.py"
    ]
    
    file_path = None
    for path in paths:
        if os.path.exists(path):
            file_path = path
            break
    
    if not file_path:
        print("❌ No se encontró spat_osc_bridge.py")
        return False
    
    print(f"✅ Archivo encontrado: {file_path}")
    
    # Crear backup
    backup_file(file_path)
    
    # Leer el archivo
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    # Aplicar correcciones
    modified = False
    new_lines = []
    
    for i, line in enumerate(lines):
        # Corrección 1: En send_aperture
        if "client.send_message(f\"/source/{spat_id}/aperture\", float(aperture_deg))" in line:
            # Ya tiene float(), está bien
            new_lines.append(line)
        elif "client.send_message(f\"/source/{spat_id}/aperture\", aperture_deg)" in line:
            # Necesita float()
            new_line = line.replace("aperture_deg)", "float(aperture_deg))")
            new_lines.append(new_line)
            modified = True
            print("✅ Corregido send_aperture()")
        
        # Corrección 2: En send_orientation (por si acaso)
        elif "client.send_message(f\"/source/{spat_id}/yaw\"" in line and "float(" not in line:
            new_line = line.replace("yaw_deg)", "float(yaw_deg))")
            new_lines.append(new_line)
            modified = True
        elif "client.send_message(f\"/source/{spat_id}/pitch\"" in line and "float(" not in line:
            new_line = line.replace("pitch_deg)", "float(pitch_deg))")
            new_lines.append(new_line)
            modified = True
        elif "client.send_message(f\"/source/{spat_id}/roll\"" in line and "float(" not in line:
            new_line = line.replace("roll_deg)", "float(roll_deg))")
            new_lines.append(new_line)
            modified = True
        
        # Corrección 3: En _send_individual_messages
        elif "self.OSC_PATHS['aperture'].format(source_index)," in line:
            # La siguiente línea debería tener el valor
            new_lines.append(line)
            if i + 1 < len(lines):
                next_line = lines[i + 1]
                if "float(apertures[i])" in next_line:
                    # Necesita conversión del valor interno también
                    new_next_line = next_line.replace(
                        "float(apertures[i])",
                        "float(10.0 + (float(apertures[i]) * 170.0))"
                    )
                    new_lines.append(new_next_line)
                    lines[i + 1] = ""  # Marcar como procesada
                    modified = True
                    print("✅ Corregido _send_individual_messages()")
                elif "float(10.0 + (apertures[i] * 170.0))" in next_line:
                    # Asegurar conversión interna
                    new_next_line = next_line.replace(
                        "(apertures[i] * 170.0)",
                        "(float(apertures[i]) * 170.0)"
                    )
                    new_lines.append(new_next_line)
                    lines[i + 1] = ""  # Marcar como procesada
                    modified = True
                    print("✅ Mejorado _send_individual_messages()")
        
        # Corrección 4: En send_position - asegurar float para las coordenadas
        elif "[float(pos_list[0]), float(pos_list[1]), float(pos_list[2])]" in line:
            # Ya está bien
            new_lines.append(line)
        elif "client.send_message(address, [" in line and "pos_list" in line:
            # Necesita float()
            new_line = line.replace(
                "[pos_list[0], pos_list[1], pos_list[2]]",
                "[float(pos_list[0]), float(pos_list[1]), float(pos_list[2])]"
            )
            new_lines.append(new_line)
            modified = True
            print("✅ Corregido send_position()")
        
        else:
            if line:  # No agregar líneas vacías marcadas
                new_lines.append(line)
    
    # Escribir el archivo corregido
    if modified:
        with open(file_path, 'w') as f:
            f.writelines(new_lines)
        print("\n✅ Archivo corregido exitosamente")
    else:
        print("\n⚠️  No se encontraron cambios necesarios")
        print("   (puede que ya esté corregido)")
    
    return True


def add_numpy_conversion_helper():
    """Agregar función helper para conversión de numpy"""
    
    helper_code = '''
def ensure_python_float(value):
    """Convertir cualquier tipo numérico a float nativo de Python"""
    try:
        # Si es numpy, usar item() o float()
        if hasattr(value, 'item'):
            return float(value.item())
        else:
            return float(value)
    except:
        return float(value) if value is not None else 0.0
'''
    
    print("\n💡 FUNCIÓN HELPER RECOMENDADA:")
    print("Agregar esta función al inicio de spat_osc_bridge.py:")
    print(helper_code)


def verify_fix():
    """Verificar que la corrección funcione"""
    
    test_script = '''#!/usr/bin/env python3
"""Verificar que la corrección funciona"""

from trajectory_hub import EnhancedTrajectoryEngine, SpatOSCBridge, OSCTarget
import time

print("\\n🧪 VERIFICACIÓN DE LA CORRECCIÓN")
print("=" * 60)

# Crear sistema
engine = EnhancedTrajectoryEngine(max_sources=10, fps=60, enable_modulator=True)
bridge = SpatOSCBridge(targets=[OSCTarget("127.0.0.1", 9000)], fps=60, source_offset=1)
engine.osc_bridge = bridge

# Crear macro
macro_id = engine.create_macro("verify_test", source_count=5, formation="line", spacing=2.0)

# Probar diferentes presets
presets = [
    ("respiración_suave", "Suave y orgánico"),
    ("nervioso_aleatorio", "Rápido y errático"),
    ("flotación_oceánica", "Ondulante"),
    ("rotación_mecánica", "Fijo y mecánico")
]

for preset_name, desc in presets:
    print(f"\\n📌 Probando preset '{preset_name}' - {desc}")
    engine.apply_orientation_preset(macro_id, preset_name, intensity=1.0)
    
    # Ejecutar durante 3 segundos
    start_time = time.time()
    while (time.time() - start_time) < 3.0:
        engine.update(1/60.0)
        time.sleep(1/60.0)
    
    print("   ¿Cambió aperture en Spat? (deberías ver movimiento)")

# Estadísticas
stats = bridge.get_stats()
print(f"\\n📊 Estadísticas:")
print(f"   - Mensajes enviados: {stats['messages_sent']:,}")
print(f"   - Aperturas enviadas: {stats['parameters_sent'].get('apertures', 0):,}")
print(f"   - Errores: {stats['messages_failed']}")

print("\\n✅ Si ves cambios en aperture, ¡la corrección funcionó!")
'''
    
    with open("verify_numpy_fix.py", "w") as f:
        f.write(test_script)
    
    print("\n✅ Script de verificación guardado: verify_numpy_fix.py")


def main():
    """Aplicar la solución definitiva"""
    
    print("\n🚀 SOLUCIÓN DEFINITIVA PARA EL PROBLEMA NUMPY/OSC")
    print("=" * 60)
    
    print("\nEl problema: pythonosc NO acepta tipos numpy")
    print("La solución: Convertir SIEMPRE a float() de Python")
    
    print("\n¿Qué hace este script?")
    print("1. Busca spat_osc_bridge.py")
    print("2. Crea un backup")
    print("3. Modifica TODOS los send_message para usar float()")
    print("4. Crea un script de verificación")
    
    response = input("\n¿Aplicar la corrección? (s/n): ").lower()
    
    if response == 's':
        if fix_spat_osc_bridge():
            add_numpy_conversion_helper()
            verify_fix()
            
            print("\n\n✅ CORRECCIÓN APLICADA")
            print("\nPasos siguientes:")
            print("1. Ejecuta: python verify_numpy_fix.py")
            print("2. Observa si aperture cambia en Spat")
            print("3. Si funciona, ¡el problema está resuelto!")
        else:
            print("\n❌ No se pudo aplicar la corrección")
    else:
        print("\nCancelado por el usuario")


if __name__ == "__main__":
    main()