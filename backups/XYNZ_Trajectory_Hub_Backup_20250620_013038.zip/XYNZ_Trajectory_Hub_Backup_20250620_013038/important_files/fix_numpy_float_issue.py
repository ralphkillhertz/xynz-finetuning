#!/usr/bin/env python3
"""
fix_numpy_float_issue.py - Solución para el problema de tipos numpy en OSC

HIPÓTESIS: Spat no está procesando correctamente numpy.float32/float64
pero sí acepta float nativo de Python.
"""

import numpy as np
from pythonosc import udp_client
import time


def test_data_types():
    """Probar diferentes tipos de datos para aperture"""
    
    print("\n🔬 TEST DE TIPOS DE DATOS PARA APERTURE")
    print("=" * 60)
    
    client = udp_client.SimpleUDPClient("127.0.0.1", 9000)
    
    # Valor de prueba
    test_value = 127.0  # Valor medio para aperture
    source_id = 1
    path = f"/source/{source_id}/aperture"
    
    print(f"\nEnviando {path} con diferentes tipos de datos...")
    print("Observa cuál hace que Spat cambie el valor:\n")
    
    # Test 1: float nativo de Python
    print("1. Python float (float()):")
    py_float = float(test_value)
    print(f"   Tipo: {type(py_float)}, Valor: {py_float}")
    client.send_message(path, py_float)
    time.sleep(2)
    
    # Test 2: numpy float32
    print("\n2. Numpy float32:")
    np_float32 = np.float32(test_value)
    print(f"   Tipo: {type(np_float32)}, Valor: {np_float32}")
    client.send_message(path, np_float32)
    time.sleep(2)
    
    # Test 3: numpy float64
    print("\n3. Numpy float64:")
    np_float64 = np.float64(test_value)
    print(f"   Tipo: {type(np_float64)}, Valor: {np_float64}")
    client.send_message(path, np_float64)
    time.sleep(2)
    
    # Test 4: Conversión explícita de numpy a Python
    print("\n4. Numpy -> Python float:")
    np_value = np.float32(test_value)
    py_from_np = float(np_value)
    print(f"   Tipo original: {type(np_value)}")
    print(f"   Tipo convertido: {type(py_from_np)}")
    client.send_message(path, py_from_np)
    time.sleep(2)
    
    # Test 5: Item() method
    print("\n5. Usando .item() de numpy:")
    np_value = np.float32(test_value)
    item_value = np_value.item()
    print(f"   Tipo: {type(item_value)}, Valor: {item_value}")
    client.send_message(path, item_value)
    
    print("\n\n¿Cuál(es) funcionó/funcionaron?")


def show_fix_for_spat_osc_bridge():
    """Mostrar la corrección para spat_osc_bridge.py"""
    
    print("\n\n🔧 CORRECCIÓN PARA spat_osc_bridge.py")
    print("=" * 60)
    
    print("""
Si el problema es el tipo de dato numpy, la corrección es:

En spat_osc_bridge.py, método send_aperture():

    def send_aperture(self, source_id: int, aperture: float):
        '''Enviar apertura/directividad de una fuente'''
        if not self._check_rate_limit():
            return
            
        # CORRECCIÓN: Asegurar conversión a float de Python
        try:
            # Convertir a float nativo de Python (no numpy)
            if isinstance(aperture, (np.float32, np.float64, np.ndarray)):
                aperture = float(aperture)
            else:
                aperture = float(aperture)
                
            aperture_deg = 10.0 + (aperture * 170.0)
            
            # IMPORTANTE: Asegurar que aperture_deg también es float de Python
            aperture_deg = float(aperture_deg)
            
        except (TypeError, ValueError):
            aperture_deg = 90.0
        
        for target in self.targets:
            if target.enabled:
                try:
                    spat_id = source_id + self.source_offset
                    client = self._clients.get(target.name)
                    
                    if client:
                        # Enviar como float de Python
                        client.send_message(f"/source/{spat_id}/aperture", aperture_deg)
                        ...

TAMBIÉN en _send_bundle() y _send_individual_messages() donde se envía aperture.
""")


def create_numpy_fix_patch():
    """Crear parche para corregir el problema de numpy"""
    
    patch_content = '''#!/usr/bin/env python3
"""
numpy_float_fix.py - Parche para convertir tipos numpy a float de Python
"""

import os
import shutil
from datetime import datetime

def apply_numpy_fix():
    """Aplicar corrección de tipos numpy"""
    
    # Buscar spat_osc_bridge.py
    paths = [
        "trajectory_hub/core/spat_osc_bridge.py",
        "spat_osc_bridge.py"
    ]
    
    file_path = None
    for path in paths:
        if os.path.exists(path):
            file_path = path
            break
    
    if not file_path:
        print("❌ No se encontró spat_osc_bridge.py")
        return False
    
    # Backup
    backup = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(file_path, backup)
    print(f"✅ Backup: {backup}")
    
    # Leer archivo
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Agregar import si no existe
    if "import numpy as np" not in content:
        content = "import numpy as np\\n" + content
    
    # Buscar y reemplazar en send_aperture
    # Esta es una versión simplificada - en producción sería más robusta
    
    old_line = "aperture_deg = float(10.0 + (aperture * 170.0))"
    new_lines = """# Asegurar conversión a float de Python (no numpy)
        if isinstance(aperture, (np.float32, np.float64, np.ndarray)):
            aperture = float(aperture)
        aperture_deg = float(10.0 + (aperture * 170.0))"""
    
    if old_line in content:
        content = content.replace(old_line, new_lines)
        print("✅ Corregido send_aperture()")
    
    # También en _send_individual_messages
    old_pattern = "float(10.0 + (apertures[i] * 170.0))"
    new_pattern = "float(10.0 + (float(apertures[i]) * 170.0))"
    
    if old_pattern in content:
        content = content.replace(old_pattern, new_pattern)
        print("✅ Corregido _send_individual_messages()")
    
    # Escribir archivo
    with open(file_path, 'w') as f:
        f.write(content)
    
    print("\\n✅ Parche aplicado exitosamente")
    return True

if __name__ == "__main__":
    print("\\n🔧 PARCHE PARA PROBLEMA DE TIPOS NUMPY")
    print("=" * 60)
    
    response = input("\\n¿Aplicar parche? (s/n): ").lower()
    if response == 's':
        if apply_numpy_fix():
            print("\\n✅ Ahora prueba los presets nuevamente")
'''
    
    with open("numpy_float_fix.py", "w") as f:
        f.write(patch_content)
    
    print("\n✅ Parche guardado: numpy_float_fix.py")


def test_timing_hypothesis():
    """Probar si el problema es el timing"""
    
    print("\n\n⏱️ TEST DE TIMING")
    print("=" * 60)
    
    client = udp_client.SimpleUDPClient("127.0.0.1", 9000)
    
    print("\nEnviando ráfagas de mensajes con diferentes delays...")
    
    # Test 1: Sin delay (como los presets)
    print("\n1. Sin delay entre mensajes:")
    for i in range(5):
        value = 10.0 + (i * 40.0)
        client.send_message("/source/1/aperture", float(value))
        print(f"   Enviado: {value}°")
    
    time.sleep(3)
    
    # Test 2: Con delay pequeño
    print("\n2. Con 50ms de delay:")
    for i in range(5):
        value = 10.0 + (i * 40.0)
        client.send_message("/source/2/aperture", float(value))
        print(f"   Enviado: {value}°")
        time.sleep(0.05)
    
    time.sleep(3)
    
    # Test 3: Con delay mayor
    print("\n3. Con 200ms de delay:")
    for i in range(5):
        value = 10.0 + (i * 40.0)
        client.send_message("/source/3/aperture", float(value))
        print(f"   Enviado: {value}°")
        time.sleep(0.2)
    
    print("\n\n¿Cuál funcionó mejor?")


def main():
    """Menú principal"""
    
    print("\n🔍 DIAGNÓSTICO: POR QUÉ LOS TESTS FUNCIONAN PERO LOS PRESETS NO")
    print("=" * 60)
    
    while True:
        print("\n\nOPCIONES:")
        print("1. Test de tipos de datos")
        print("2. Test de timing")
        print("3. Ver corrección para tipos numpy")
        print("4. Crear parche para tipos numpy")
        print("5. Comparar mensajes OSC")
        print("6. Salir")
        
        choice = input("\nSelecciona una opción (1-6): ")
        
        if choice == '1':
            test_data_types()
        elif choice == '2':
            test_timing_hypothesis()
        elif choice == '3':
            show_fix_for_spat_osc_bridge()
        elif choice == '4':
            create_numpy_fix_patch()
        elif choice == '5':
            os.system("python compare_osc_messages.py")
        elif choice == '6':
            break
    
    print("\n\n📊 HIPÓTESIS MÁS PROBABLE")
    print("=" * 60)
    print("""
Los logs de Spat muestran que los valores LLEGAN correctamente,
pero si no se aplican visualmente, el problema más probable es:

1. TIPO DE DATO: numpy.float32/64 vs float de Python
   - pythonosc puede serializar diferente según el tipo
   - Spat puede interpretar diferente según el formato OSC

2. TIMING: Los presets envían muy rápido
   - Spat puede tener un límite de procesamiento
   - Los mensajes se pueden estar descartando

3. CONTEXTO: Los presets envían muchos parámetros juntos
   - Aperture se envía junto con position, orientation, etc.
   - Puede haber interferencia entre parámetros

La solución más directa es asegurar que SIEMPRE se envíe
float nativo de Python, no numpy.
""")


if __name__ == "__main__":
    main()