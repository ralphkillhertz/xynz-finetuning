#!/usr/bin/env python3
"""
fix_aperture_presets.py - Diagnóstico y corrección del sistema de aperture

PROBLEMA PRINCIPAL: La cadena de actualización de aperture está rota en varios puntos
"""

import time
import numpy as np
from pythonosc import udp_client
import logging

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def diagnose_aperture_flow():
    """Diagnosticar el flujo completo de aperture"""
    
    print("\n🔍 DIAGNÓSTICO DEL FLUJO DE APERTURE")
    print("=" * 60)
    
    print("""
FLUJO DE DATOS IDENTIFICADO:

1. PRESET → MODULADOR:
   - Preset define: aperture_base y aperture_mod
   - apply_preset() asigna estos valores al modulador
   
2. MODULADOR → STATE:
   - modulator.update() calcula: 
     aperture_mod = sin(phase * 0.5) * aperture_modulation * intensity
     state.aperture = clip(aperture_base + aperture_mod, 0.0, 1.0)
   
3. STATE → ARRAYS GLOBALES:
   - En enhanced_trajectory_engine.update():
     self._apertures[sid] = motion.state.aperture
     
4. ARRAYS → OSC:
   ❌ PROBLEMA: El código actual NO envía aperture a OSC
   - Falta: self.osc_bridge.send_aperture(sid, self._apertures[sid])

5. OSC → SPAT:
   - send_aperture() convierte 0-1 → 10-180°
   - Envía a /source/{id}/aperture
""")


def test_modulator_aperture():
    """Test directo del modulador de aperture"""
    
    print("\n\n🧪 TEST DEL MODULADOR")
    print("=" * 60)
    
    try:
        from trajectory_hub.core.motion_components import AdvancedOrientationModulation, MotionState
        
        # Crear modulador
        modulator = AdvancedOrientationModulation()
        state = MotionState()
        
        print("\n1. Valores por defecto:")
        print(f"   aperture_base: {modulator.aperture_base}")
        print(f"   aperture_modulation: {modulator.aperture_modulation}")
        print(f"   state.aperture: {state.aperture}")
        
        # Aplicar preset
        print("\n2. Aplicando preset 'respiración_suave':")
        modulator.apply_preset("respiración_suave")
        print(f"   aperture_base: {modulator.aperture_base}")
        print(f"   aperture_modulation: {modulator.aperture_modulation}")
        
        # Simular actualizaciones
        print("\n3. Simulando 20 actualizaciones:")
        dt = 1/60.0
        for i in range(20):
            current_time = i * dt
            state = modulator.update(current_time, dt, state)
            if i % 5 == 0:
                print(f"   t={current_time:.2f}s: aperture = {state.aperture:.3f}")
        
        print("\n✅ El modulador actualiza aperture correctamente")
        return True
        
    except Exception as e:
        print(f"\n❌ Error en modulador: {e}")
        import traceback
        traceback.print_exc()
        return False


def create_aperture_fix_patch():
    """Crear parche para corregir el envío de aperture"""
    
    print("\n\n🔧 PARCHE DE CORRECCIÓN")
    print("=" * 60)
    
    patch_code = '''
# PARCHE PARA enhanced_trajectory_engine.py
# Agregar después de la línea: self._apertures[sid] = motion.state.aperture

# En el método update(), sección "ENVIAR ACTUALIZACIONES OSC":

        # ========== ENVIAR ACTUALIZACIONES OSC (solo activos) ==========
        if self.osc_bridge and self._check_rate_limit():
            for sid in active_sources:
                # Enviar posición siempre
                self.osc_bridge.send_position(sid, self._positions[sid])
                
                # Enviar orientación y apertura si el modulador está activo
                if self.enable_modulator and sid in self.orientation_modulators:
                    modulator = self.orientation_modulators[sid]
                    if modulator.enabled:
                        # Enviar orientación
                        self.osc_bridge.send_orientation(
                            sid,
                            self._orientations[sid][0],  # yaw
                            self._orientations[sid][1],  # pitch
                            self._orientations[sid][2]   # roll
                        )
                        
                        # IMPORTANTE: Enviar apertura
                        self.osc_bridge.send_aperture(sid, self._apertures[sid])
'''
    
    print(patch_code)
    
    # Guardar parche
    with open("aperture_fix.patch", "w") as f:
        f.write(patch_code)
    
    print("\n✅ Parche guardado en: aperture_fix.patch")


def test_aperture_with_engine():
    """Test completo con el engine y OSC"""
    
    print("\n\n🧪 TEST CON ENGINE COMPLETO")
    print("=" * 60)
    
    try:
        from trajectory_hub import EnhancedTrajectoryEngine, SpatOSCBridge, OSCTarget
        
        # Crear sistema
        print("\n1. Creando sistema...")
        engine = EnhancedTrajectoryEngine(
            max_sources=20,
            fps=60,
            enable_modulator=True
        )
        
        bridge = SpatOSCBridge(
            targets=[OSCTarget("127.0.0.1", 9000)],
            fps=60,
            source_offset=1
        )
        
        engine.osc_bridge = bridge
        
        # Crear macro
        print("\n2. Creando macro con 3 fuentes...")
        macro_id = engine.create_macro(
            name="aperture_test",
            source_count=3,
            formation="triangle"
        )
        
        # Verificar estado inicial
        macro = engine._macros[macro_id]
        source_ids = list(macro.source_ids)
        
        print(f"\n3. Fuentes creadas: {source_ids}")
        print("   Estados iniciales:")
        for sid in source_ids:
            if sid in engine._apertures:
                print(f"   - Fuente {sid}: aperture = {engine._apertures[sid]:.3f}")
        
        # Aplicar preset
        print("\n4. Aplicando preset 'flotación_oceánica'...")
        success = engine.apply_orientation_preset(macro_id, "flotación_oceánica")
        
        if success:
            # Verificar que el preset se aplicó
            for sid in source_ids:
                if sid in engine.orientation_modulators:
                    mod = engine.orientation_modulators[sid]
                    print(f"   - Fuente {sid}: aperture_base = {mod.aperture_base:.3f}")
        
        # Actualizar y verificar
        print("\n5. Ejecutando actualizaciones...")
        
        # Habilitar debug temporal en send_aperture
        original_level = logger.level
        logger.setLevel(logging.DEBUG)
        
        aperture_sent_count = 0
        start_stats = bridge.get_stats()
        initial_apertures = start_stats['parameters_sent'].get('apertures', 0)
        
        for i in range(60):  # 1 segundo
            engine.update(1/60.0)
            
            # Verificar cada 20 frames
            if i % 20 == 0:
                print(f"\n   Frame {i}:")
                for sid in source_ids[:2]:  # Primeras 2 fuentes
                    if sid in engine._apertures:
                        aperture = engine._apertures[sid]
                        aperture_deg = 10.0 + (aperture * 170.0)
                        print(f"   - F{sid}: {aperture:.3f} → {aperture_deg:.1f}°")
            
            time.sleep(1/60.0)
        
        # Verificar estadísticas
        end_stats = bridge.get_stats()
        final_apertures = end_stats['parameters_sent'].get('apertures', 0)
        apertures_sent = final_apertures - initial_apertures
        
        print(f"\n6. Estadísticas:")
        print(f"   - Aperturas enviadas: {apertures_sent}")
        print(f"   - Mensajes totales: {end_stats['messages_sent'] - start_stats['messages_sent']}")
        
        logger.setLevel(original_level)
        
        if apertures_sent == 0:
            print("\n❌ NO SE ENVIARON APERTURAS - El parche es necesario")
            return False
        else:
            print("\n✅ Sistema funcionando correctamente")
            return True
            
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def manual_aperture_test():
    """Test manual enviando aperture directamente"""
    
    print("\n\n🔧 TEST MANUAL DE APERTURE")
    print("=" * 60)
    
    client = udp_client.SimpleUDPClient("127.0.0.1", 9000)
    
    # Test con diferentes presets
    presets_apertures = {
        "respiración_suave": (0.7, 0.1),     # base, mod
        "flotación_oceánica": (0.8, 0.1),
        "nervioso_aleatorio": (0.2, 0.3),
        "rotación_mecánica": (0.2, 0.0),
        "órbita_estable": (0.5, 0.05)
    }
    
    print("\nEnviando valores de aperture de cada preset:")
    print("(Observa los cambios en Spat)")
    
    for preset_name, (base, mod) in presets_apertures.items():
        print(f"\n📌 {preset_name}:")
        print(f"   Base: {base:.1f} ({10 + base * 170:.0f}°)")
        print(f"   Modulación: ±{mod:.1f} ({mod * 170:.0f}°)")
        
        # Simular modulación
        for i in range(50):  # ~1 segundo a 50Hz
            t = i / 50.0
            phase = t * 2 * np.pi
            
            # Calcular aperture con modulación
            aperture_mod = np.sin(phase * 0.5) * mod
            aperture = np.clip(base + aperture_mod, 0.0, 1.0)
            aperture_deg = 10.0 + (aperture * 170.0)
            
            # Enviar a las primeras 5 fuentes con desfase
            for source_id in range(1, 6):
                source_phase = phase + (source_id - 1) * 0.2
                source_mod = np.sin(source_phase * 0.5) * mod
                source_aperture = np.clip(base + source_mod, 0.0, 1.0)
                source_aperture_deg = 10.0 + (source_aperture * 170.0)
                
                path = f"/source/{source_id}/aperture"
                client.send_message(path, float(source_aperture_deg))
            
            # Mostrar progreso
            if i % 10 == 0:
                print(f"   t={t:.1f}s: {aperture_deg:.1f}°", end="\r", flush=True)
            
            time.sleep(0.02)
        
        print()  # Nueva línea
        time.sleep(0.5)  # Pausa entre presets
    
    print("\n✅ Test manual completado")


def verify_preset_values():
    """Verificar los valores de aperture en todos los presets"""
    
    print("\n\n📊 VALORES DE APERTURE EN PRESETS")
    print("=" * 60)
    
    try:
        from trajectory_hub.core.motion_components import AdvancedOrientationModulation
        
        modulator = AdvancedOrientationModulation()
        
        print("\nPreset                    | Base  | Mod   | Rango (°)")
        print("-" * 60)
        
        for preset_name, preset_data in modulator.presets.items():
            base = preset_data["aperture"]
            mod = preset_data.get("aperture_mod", 0.0)
            
            min_val = max(0.0, base - mod)
            max_val = min(1.0, base + mod)
            
            min_deg = 10.0 + (min_val * 170.0)
            max_deg = 10.0 + (max_val * 170.0)
            
            print(f"{preset_name:24} | {base:.2f} | {mod:.2f} | {min_deg:.0f}° - {max_deg:.0f}°")
        
        print("\n✅ Todos los valores están en rango válido (0-1)")
        
    except Exception as e:
        print(f"\n❌ Error verificando presets: {e}")


def main():
    """Función principal"""
    
    print("\n🚀 DIAGNÓSTICO Y CORRECCIÓN DE APERTURE")
    print("=" * 60)
    
    while True:
        print("\n\nOPCIONES:")
        print("1. Diagnóstico del flujo de datos")
        print("2. Test del modulador")
        print("3. Test con engine completo")
        print("4. Test manual de aperture")
        print("5. Verificar valores de presets")
        print("6. Crear parche de corrección")
        print("7. Ejecutar todos los tests")
        print("8. Salir")
        
        choice = input("\nSelecciona una opción (1-8): ")
        
        if choice == '1':
            diagnose_aperture_flow()
        elif choice == '2':
            test_modulator_aperture()
        elif choice == '3':
            test_aperture_with_engine()
        elif choice == '4':
            manual_aperture_test()
        elif choice == '5':
            verify_preset_values()
        elif choice == '6':
            create_aperture_fix_patch()
        elif choice == '7':
            # Ejecutar todos los tests
            diagnose_aperture_flow()
            test_modulator_aperture()
            verify_preset_values()
            test_aperture_with_engine()
            print("\n\n🎯 CONCLUSIÓN:")
            print("Si aperture no funciona, aplica el parche del opción 6")
        elif choice == '8':
            break
        else:
            print("Opción inválida")
    
    print("\n\n📝 RESUMEN FINAL:")
    print("=" * 60)
    print("""
El problema principal es que enhanced_trajectory_engine.py NO envía
los valores de aperture por OSC aunque los calcula correctamente.

SOLUCIÓN:
1. Aplicar el parche generado (opción 6)
2. En el método update(), agregar:
   self.osc_bridge.send_aperture(sid, self._apertures[sid])
   
3. Verificar que el parche funcione con la opción 3

Para la demo de modulación, el problema puede estar relacionado
con la forma en que se conecta el bridge OSC al engine.
""")


if __name__ == "__main__":
    main()