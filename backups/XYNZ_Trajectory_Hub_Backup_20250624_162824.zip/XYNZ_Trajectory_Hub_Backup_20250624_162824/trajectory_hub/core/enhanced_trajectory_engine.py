"""
enhanced_trajectory_engine.py - Motor de trayectorias con sistema de componentes completo
Evolución de extended_path_engine.py que mantiene compatibilidad e integra motion_components
"""
from __future__ import annotations
import numpy as np
import logging
import time
from typing import Dict, List, Optional, Callable, Set, Tuple, Any
from dataclasses import dataclass, field

# Importar el sistema de componentes
from trajectory_hub.core.motion_components import (
    SourceMotion, TrajectoryMovementMode, TrajectoryDisplacementMode,
    OrientationModulation, IndividualTrajectory, TrajectoryTransform,
    MacroTrajectory, create_complex_movement, MotionState,
    AdvancedOrientationModulation
)
from trajectory_hub.core.trajectory_deformers import (
    CompositeDeformer, ForceFieldDeformation, WaveDeformation,
    ChaoticDeformation, GestureDeformation, BlendMode
)
# Mantener compatibilidad con el sistema anterior
from trajectory_hub.core.extended_path_engine import (
    BoidParams, SourceInfo, MacroSource,
    _NUMBA_AVAILABLE, _BEHAVIORS_AVAILABLE
)

logger = logging.getLogger(__name__)


@dataclass
class EnhancedMacroSource(MacroSource):
    """Versión mejorada de MacroSource con soporte para el nuevo sistema"""

    # Campos base heredados de MacroSource
    name: str = ""
    behavior_name: str = "flock"

    # Componente de trayectoria macro
    trajectory_component: Optional[MacroTrajectory] = None
    
    # Configuración de trayectorias individuales
    individual_trajectories: Dict[int, str] = field(default_factory=dict)  # source_id: shape_type
    allow_different_trajectories: bool = False
    
    # Estado de concentración
    concentration_active: bool = False
    concentration_point: np.ndarray = field(default_factory=lambda: np.zeros(3))
    concentration_duration: float = 1.0
    
    # Deformador
    deformer: Optional[CompositeDeformer] = None
    deformation_enabled: bool = False

    def __post_init__(self):
        """Inicializar la clase padre MacroSource y configurar componentes"""
        # Inicializar los atributos de MacroSource de forma segura
        try:
            # Usar los valores por defecto si no están establecidos
            macro_id = getattr(self, 'id', f"macro_{id(self)}")
            name = getattr(self, 'name', f"Macro_{macro_id}")
            behavior = getattr(self, 'behavior_name', 'flock')
            
            # Llamar al constructor padre
            super().__init__(macro_id, name, behavior)
        except Exception as e:
            # Si hay algún problema, inicializar manualmente los atributos críticos
            logger.warning(f"Error en __post_init__: {e}. Inicializando manualmente.")
            if not hasattr(self, 'source_ids'):
                self.source_ids = set()
            if not hasattr(self, 'behavior'):
                self.behavior = None
                
        # Asegurar que trajectory_component se inicialice
        if self.trajectory_component is None:
            from trajectory_hub.core.motion_components import MacroTrajectory
            self.trajectory_component = MacroTrajectory()


class EnhancedTrajectoryEngine:
    """
    Motor de trayectorias mejorado que integra el sistema de componentes
    Mantiene compatibilidad con la API anterior mientras añade nuevas capacidades
    """
    
    def __init__(self, max_sources: int = 64, fps: int = 60, 
                 params: Optional[BoidParams] = None,
                 use_legacy_mode: bool = False,
                 enable_modulator: bool = True):
        """
        Parameters
        ----------
        max_sources : int
            Número máximo de fuentes
        fps : int
            Frames por segundo
        params : BoidParams
            Parámetros de comportamiento boids
        use_legacy_mode : bool
            Si True, usa el comportamiento anterior (para compatibilidad)
        enable_modulator : bool
            Si True, habilita el sistema de modulación de orientación
        """
        self.max_sources = max_sources
        self.fps = fps
        self.dt = 1.0 / fps
        self.params = params or BoidParams()
        self.use_legacy_mode = use_legacy_mode
        
        # Sistema de componentes nuevo
        self._source_motions: Dict[int, SourceMotion] = {}
        
        # Información de fuentes y macros (compatible con versión anterior)
        self._source_info: Dict[int, SourceInfo] = {}
        self._macros: Dict[str, EnhancedMacroSource] = {}
        
        # Estado interno
        self._time = 0.0
        self._frame_count = 0
        
        # Arrays para compatibilidad y optimización
        self._positions = np.zeros((max_sources, 3), dtype=np.float32)
        self._orientations = np.zeros((max_sources, 3), dtype=np.float32)
        self._apertures = np.ones(max_sources, dtype=np.float32) * 0.5
        
        # Sistema de deformadores global
        self.global_deformer = CompositeDeformer()

        # Deformadores por macro
        self._macro_deformers: Dict[str, CompositeDeformer] = {}
        
        # Sistema de modulación de orientación
        self.enable_modulator = enable_modulator
        self.orientation_modulators = {}  # Diccionario para guardar moduladores
        
        # Configuración global del modulador
        self.global_modulator_intensity = 1.0
        self.global_modulator_preset = None
        
        # Cache de últimas orientaciones enviadas
        self._last_orientations = {}
        self._orientation_update_threshold = 0.01  # radianes
        
        # OSC Bridge (se configura externamente)
        self.osc_bridge = None
        self._is_running = True

        logger.info(f"EnhancedTrajectoryEngine inicializado ({max_sources} fuentes @ {fps} fps)")

    def create_source(self, source_id: int, name: Optional[str] = None) -> SourceMotion:
        """
        Crear una nueva fuente con sistema de componentes
        
        Parameters
        ----------
        source_id : int
            ID único de la fuente
        name : str, optional
            Nombre de la fuente
            
        Returns
        -------
        SourceMotion
            Objeto de movimiento creado
        """
        if source_id >= self.max_sources:
            raise ValueError(f"ID {source_id} excede el máximo de fuentes ({self.max_sources})")
            
        if source_id in self._source_motions:
            logger.warning(f"Fuente {source_id} ya existe, retornando existente")
            return self._source_motions[source_id]
            
        # Crear objeto de movimiento
        motion = SourceMotion(source_id)
        
        # Configurar posición inicial aleatoria
        angle = np.random.uniform(0, 2 * np.pi)
        radius = np.random.uniform(1, 3)
        motion.state.position = np.array([
            radius * np.cos(angle),
            radius * np.sin(angle),
            np.random.uniform(-0.5, 0.5)
        ])
        
        # Registrar en el sistema
        self._source_motions[source_id] = motion
        self._positions[source_id] = motion.state.position
        
        # Crear info para compatibilidad
        info = SourceInfo(
            id=str(source_id),
            name=name or f"Source_{source_id}",
            position=motion.state.position.copy()
        )
        self._source_info[source_id] = info
        
        # Crear modulador de orientación si está habilitado
        if self.enable_modulator:
            self.create_orientation_modulator(source_id)
        
        logger.info(f"Fuente {source_id} creada: {info.name}")
        return motion

    def create_orientation_modulator(self, source_id: int) -> Optional[AdvancedOrientationModulation]:
        """Crear modulador de orientación para una fuente"""
        if not self.enable_modulator:
            return None
            
        if source_id not in self._source_motions:
            logger.error(f"No se puede crear modulador para fuente inexistente {source_id}")
            return None
            
        # Crear modulador avanzado
        modulator = AdvancedOrientationModulation()
        modulator.source_id = source_id
        
        # Configurar con intensidad global
        modulator.intensity = self.global_modulator_intensity
        
        # Registrar
        self.orientation_modulators[source_id] = modulator
        
        logger.debug(f"Modulador de orientación creado para fuente {source_id}")
        return modulator

    def create_macro(
        self, 
        name: str, 
        source_count: int, 
        behavior: str = "flock",
        formation: str = "circle",
        spacing: float = 2.0,
        **kwargs
    ) -> str:
        """
        Crear un macro (grupo de fuentes)
        
        Parameters
        ----------
        name : str
            Nombre del macro
        source_count : int
            Número de fuentes en el macro
        behavior : str
            Tipo de comportamiento (flock, rigid, orbit, etc.)
        formation : str
            Formación inicial (circle, line, grid, spiral)
        spacing : float
            Espaciado entre fuentes
            
        Returns
        -------
        str
            ID del macro creado
        """
        # Generar ID único
        macro_id = f"macro_{len(self._macros)}_{name.lower().replace(' ', '_')}"
        
        # Crear conjunto de fuentes
        source_ids = []
        start_id = len(self._source_motions)
        
        for i in range(source_count):
            sid = start_id + i
            if sid < self.max_sources:
                self.create_source(sid, f"{name}_{i}")
                source_ids.append(sid)
        
        # Crear macro con los campos necesarios
        macro = EnhancedMacroSource()
        
        # Establecer campos base
        macro.id = macro_id
        macro.name = name
        macro.behavior_name = behavior
        
        # Establecer campos opcionales
        if 'allow_different_trajectories' in kwargs:
            macro.allow_different_trajectories = kwargs['allow_different_trajectories']
        
        # Añadir fuentes al macro
        for sid in source_ids:
            macro.add_source(sid)
            if sid in self._source_info:
                self._source_info[sid].macro_id = macro_id
                
        # Crear componente de trayectoria macro
        macro.trajectory_component = MacroTrajectory()
        
        # Aplicar formación inicial
        self._apply_formation(source_ids, formation, spacing)
        
        # Registrar macro
        self._macros[macro_id] = macro
        
        logger.info(f"Macro '{name}' creado con {len(source_ids)} fuentes")
        
        # Crear moduladores de orientación si está habilitado
        if self.enable_modulator:
            for i, sid in enumerate(source_ids):
                modulator = self.create_orientation_modulator(sid)
                if modulator:
                    # Desfase temporal para efecto orgánico
                    modulator.time_offset = i * 0.05
                
        # Si hay un preset global configurado, aplicarlo
        if self.global_modulator_preset:
            self.apply_orientation_preset(macro_id, self.global_modulator_preset)
            
        return macro_id

    def _apply_formation(self, source_ids: List[int], formation: str, spacing: float):
        """Aplicar formación inicial a un conjunto de fuentes"""
        total = len(source_ids)
        
        for index, sid in enumerate(source_ids):
            if sid not in self._source_motions:
                continue
                
            motion = self._source_motions[sid]
            
            if formation == "circle":
                angle = (index / total) * 2 * np.pi
                position = np.array([
                    spacing * np.cos(angle),
                    spacing * np.sin(angle),
                    0
                ])
            elif formation == "line":
                position = np.array([
                    (index - total/2) * spacing,
                    0,
                    0
                ])
            elif formation == "grid":
                side = int(np.ceil(np.sqrt(total)))
                x = (index % side - side/2) * spacing
                y = (index // side - side/2) * spacing
                position = np.array([x, y, 0])
            else:  # spiral
                angle = index * 0.5
                radius = spacing * (1 + index * 0.1)
                position = np.array([
                    radius * np.cos(angle),
                    radius * np.sin(angle),
                    index * 0.1
                ])
                
            motion.state.position = position
            self._positions[motion.id] = position

    def set_individual_trajectory(
        self,
        source_id: int,
        shape: str,
        movement_mode: TrajectoryMovementMode = TrajectoryMovementMode.FIX,
        **params
    ):
        """Configurar trayectoria individual de una fuente"""
        if source_id not in self._source_motions:
            logger.error(f"Fuente {source_id} no existe")
            return
            
        motion = self._source_motions[source_id]
        traj = motion.components.get('individual_trajectory')
        
        if isinstance(traj, IndividualTrajectory):
            # Cambiar forma
            traj.shape_type = shape
            traj.shape_func = traj._create_shape(shape)
            
            # Configurar modo de movimiento
            traj.set_movement_mode(movement_mode, **params)
            
            logger.info(f"Trayectoria individual configurada: {shape} con modo {movement_mode.value}")

    def set_macro_trajectory(
        self,
        macro_id: str,
        trajectory_func: Callable[[float], np.ndarray],
        orientation_func: Optional[Callable[[float], np.ndarray]] = None,
        enable_deformation: bool = True
    ):
        """Establecer trayectoria de un macro completo"""
        if macro_id not in self._macros:
            logger.error(f"Macro {macro_id} no existe")
            return
            
        macro = self._macros[macro_id]
        
        # Configurar componente de trayectoria
        if macro.trajectory_component:
            macro.trajectory_component.set_trajectory(trajectory_func, orientation_func)
            macro.trajectory_component.enabled = True
            
        # Habilitar deformación si se solicita
        macro.deformation_enabled = enable_deformation
        
        logger.info(f"Trayectoria establecida para macro {macro_id}")
    def set_mixed_trajectories(self, macro_id: str, shape_distribution: List[Tuple[str, float]]):
        """
        Asignar diferentes formas de trayectoria a las fuentes de un macro
        
        Parameters
        ----------
        macro_id : str
            ID del macro
        shape_distribution : List[Tuple[str, float]]
            Lista de (forma, proporción) donde proporción suma 1.0
        """
        if macro_id not in self._macros:
            logger.error(f"Macro {macro_id} no existe")
            return
            
        macro = self._macros[macro_id]
        macro.allow_different_trajectories = True
        
        source_list = list(macro.source_ids)
        total = len(source_list)
        
        # Asignar formas según distribución
        current_idx = 0
        for shape, proportion in shape_distribution:
            count = int(total * proportion)
            for i in range(count):
                if current_idx < total:
                    sid = source_list[current_idx]
                    macro.individual_trajectories[sid] = shape
                    
                    # Configurar la trayectoria individual
                    if sid in self._source_motions:
                        motion = self._source_motions[sid]
                        traj = motion.components.get('individual_trajectory')
                        if isinstance(traj, IndividualTrajectory):
                            traj.shape_type = shape
                            traj.shape_func = traj._create_shape(shape)
                            
                    current_idx += 1
                    
        logger.info(f"Trayectorias mixtas asignadas a macro {macro_id}")

    def apply_breathing(self, period: float = 5.0, amplitude: float = 1.0, 
                       macro_id: Optional[str] = None):
        """Aplicar efecto de respiración (expansión/contracción)"""
        if macro_id:
            if macro_id not in self._macro_deformers:
                self._macro_deformers[macro_id] = CompositeDeformer()
            deformer = self._macro_deformers[macro_id]
        else:
            deformer = self.global_deformer
            
        # Crear deformación de respiración
        breathing = WaveDeformation(
            wave_type="sine",
            frequency=1.0 / period,
            amplitude=amplitude,
            phase=0.0
        )
        breathing.scale_mode = True  # Modo escala
        
        deformer.add_deformation("breathing", breathing)
        logger.info(f"Respiración aplicada: período={period}s, amplitud={amplitude}")

    def apply_concentration(self, macro_id: str, point: np.ndarray, duration: float = 2.0):
        """
        Aplicar concentración temporal hacia un punto
        
        Parameters
        ----------
        macro_id : str
            ID del macro
        point : np.ndarray
            Punto de concentración
        duration : float
            Duración de la transición
        """
        if macro_id not in self._macros:
            return
            
        macro = self._macros[macro_id]
        macro.concentration_active = True
        macro.concentration_point = point.copy()
        macro.concentration_duration = duration
        
        # Aplicar a cada fuente del macro
        start_time = self._time
        for sid in macro.source_ids:
            if sid not in self._source_motions:
                continue
                
            motion = self._source_motions[sid]
            transform = motion.components.get('trajectory_transform')
            
            if isinstance(transform, TrajectoryTransform):
                # Función de interpolación temporal
                initial_offset = transform.offset.copy() if isinstance(transform.offset, np.ndarray) else np.zeros(3)
                target_offset = point - motion.state.position
                
                def concentration_func(t):
                    elapsed = t - start_time
                    if elapsed >= duration:
                        return target_offset
                    factor = elapsed / duration
                    # Ease in-out
                    factor = 0.5 * (1 - np.cos(np.pi * factor))
                    return initial_offset + (target_offset - initial_offset) * factor
                    
                transform.offset = concentration_func
                transform.enabled = True

    def apply_dispersion(self, macro_id: str, force: float = 2.0, duration: float = 1.5):
        """Aplicar dispersión desde el centro"""
        if macro_id not in self._macros:
            return
            
        macro = self._macros[macro_id]
        
        # Calcular centro actual
        positions = []
        for sid in macro.source_ids:
            if sid in self._positions:
                positions.append(self._positions[sid])
                
        if not positions:
            return
            
        center = np.mean(positions, axis=0)
        
        # Aplicar fuerza de dispersión
        start_time = self._time
        for sid in macro.source_ids:
            if sid not in self._source_motions:
                continue
                
            motion = self._source_motions[sid]
            transform = motion.components.get('trajectory_transform')
            
            if isinstance(transform, TrajectoryTransform):
                # Dirección de dispersión
                direction = motion.state.position - center
                if np.linalg.norm(direction) > 0.001:
                    direction = direction / np.linalg.norm(direction)
                else:
                    # Dirección aleatoria si está en el centro
                    angle = np.random.uniform(0, 2 * np.pi)
                    direction = np.array([np.cos(angle), np.sin(angle), 0])
                    
                initial_offset = transform.offset.copy() if isinstance(transform.offset, np.ndarray) else np.zeros(3)
                target_offset = direction * force
                
                def dispersion_func(t):
                    elapsed = t - start_time
                    if elapsed >= duration:
                        return target_offset
                    factor = elapsed / duration
                    # Ease out
                    factor = 1.0 - (1.0 - factor) ** 2
                    return initial_offset + (target_offset - initial_offset) * factor
                    
                transform.offset = dispersion_func
                transform.enabled = True

    def apply_orientation_preset(self, macro_id: str, preset_name: str):
        """Aplicar un preset de orientación a todas las fuentes de un macro"""
        if macro_id not in self._macros:
            logger.error(f"Macro {macro_id} no encontrado")
            return
            
        macro = self._macros[macro_id]
        
        for sid in macro.source_ids:
            if sid in self.orientation_modulators:
                modulator = self.orientation_modulators[sid]
                modulator.apply_preset(preset_name)
                logger.debug(f"Preset '{preset_name}' aplicado a fuente {sid}")
                
        logger.info(f"Preset de orientación '{preset_name}' aplicado a macro {macro_id}")

    def set_modulator_intensity(self, intensity: float, macro_id: Optional[str] = None):
        """Establecer intensidad del modulador (0-1)"""
        intensity = np.clip(intensity, 0.0, 1.0)
        
        if macro_id:
            # Aplicar solo a un macro
            if macro_id in self._macros:
                macro = self._macros[macro_id]
                for sid in macro.source_ids:
                    if sid in self.orientation_modulators:
                        self.orientation_modulators[sid].intensity = intensity
        else:
            # Aplicar globalmente
            self.global_modulator_intensity = intensity
            for modulator in self.orientation_modulators.values():
                modulator.intensity = intensity
                
        logger.info(f"Intensidad del modulador establecida a {intensity:.1%}")

    def update(self, dt: float) -> Dict[str, Any]:
        """
        Actualizar el sistema completo - VERSIÓN OPTIMIZADA
        Solo procesa fuentes que están en macros activos
        """
        t = self._time
        
        # ========== DETERMINAR FUENTES ACTIVAS ==========
        active_sources = set()
        for macro in self._macros.values():
            active_sources.update(macro.source_ids)
        
        # Si no hay fuentes activas, no hacer nada
        if not active_sources:
            self._time += dt
            self._frame_count += 1
            return {
                'positions': {},
                'orientations': {},
                'apertures': {},
                'names': {},
                'time': self._time,
                'frame': self._frame_count
            }
        
        # ========== ACTUALIZAR SOLO FUENTES ACTIVAS ==========
        for sid in active_sources:
            if sid not in self._source_motions:
                continue
                
            motion = self._source_motions[sid]
            pos, orient, aperture = motion.update(t, dt)
            
            # Actualizar arrays globales
            self._positions[sid] = pos
            self._orientations[sid] = orient
            self._apertures[sid] = aperture
        
        # ========== ACTUALIZAR MODULADORES (solo activos) ==========
        if self.enable_modulator:
            current_time = time.time()
            for sid in active_sources:
                if sid in self.orientation_modulators:
                    modulator = self.orientation_modulators[sid]
                    if modulator.enabled:
                        # Actualizar estado con modulación
                        motion = self._source_motions[sid]
                        motion.state = modulator.update(current_time, dt, motion.state)
                        # Actualizar arrays globales con las nuevas orientaciones
                        self._orientations[sid] = motion.state.orientation
                        self._apertures[sid] = motion.state.aperture
        
        # ========== ENVIAR ACTUALIZACIONES OSC (solo activos) ==========
        if self.osc_bridge and self._check_rate_limit():
            for sid in active_sources:
                # Enviar posición
                self.osc_bridge.send_position(sid, self._positions[sid])
                
                # Enviar orientación si el modulador está activo
                if self.enable_modulator and sid in self.orientation_modulators:
                    modulator = self.orientation_modulators[sid]
                    if modulator.enabled:
                        # Solo enviar si cambió significativamente
                        if sid not in self._last_orientations or \
                           np.linalg.norm(self._orientations[sid] - self._last_orientations.get(sid, np.zeros(3))) > self._orientation_update_threshold:
                            self.osc_bridge.send_orientation(
                                sid,
                                self._orientations[sid][0],  # yaw
                                self._orientations[sid][1],  # pitch
                                self._orientations[sid][2]   # roll
                            )
                            self.osc_bridge.send_aperture(sid, self._apertures[sid])
                            self._last_orientations[sid] = self._orientations[sid].copy()
        
        # Incrementar tiempo
        self._time += dt
        self._frame_count += 1
        
        # Preparar respuesta solo con fuentes activas
        active_positions = {sid: self._positions[sid] for sid in active_sources}
        active_orientations = {sid: self._orientations[sid] for sid in active_sources}
        active_apertures = {sid: self._apertures[sid] for sid in active_sources}
        active_names = {sid: self._source_info[sid].name for sid in active_sources if sid in self._source_info}
        
        return {
            'positions': active_positions,
            'orientations': active_orientations,
            'apertures': active_apertures,
            'names': active_names,
            'time': self._time,
            'frame': self._frame_count
        }

    def step(self) -> Dict[str, Any]:
        """
        Método de compatibilidad para InteractiveController
        Llama a update() y devuelve el estado
        """
        return self.update(self.dt)

    def get_debug_info(self, source_id: int) -> Dict[str, Any]:
        """Obtener información de debug de una fuente"""
        if source_id not in self._source_motions:
            return {"error": "Fuente no encontrada"}
            
        motion = self._source_motions[source_id]
        info = {
            "id": source_id,
            "position": motion.state.position.tolist(),
            "orientation": motion.state.orientation.tolist(),
            "aperture": motion.state.aperture,
            "components": {}
        }
        
        for name, component in motion.components.items():
            comp_info = {
                "enabled": component.enabled,
                "weight": component.weight
            }
            
            if isinstance(component, IndividualTrajectory):
                comp_info.update({
                    "shape": component.shape_type,
                    "movement_mode": component.movement_mode.value,
                    "position_on_trajectory": component.position_on_trajectory
                })
            elif isinstance(component, TrajectoryTransform):
                comp_info.update({
                    "displacement_mode": component.displacement_mode.value,
                    "offset": component.offset.tolist() if isinstance(component.offset, np.ndarray) else str(component.offset)
                })
            elif isinstance(component, OrientationModulation):
                comp_info.update({
                    "has_yaw": component.yaw_func is not None,
                    "has_pitch": component.pitch_func is not None,
                    "has_roll": component.roll_func is not None
                })
                
            info["components"][name] = comp_info
            
        return info

    # ========== MÉTODOS DE COMPATIBILIDAD ==========
    
    def set_source_name(self, source_id: int, name: str):
        """Compatibilidad: establecer nombre de fuente"""
        if source_id in self._source_info:
            self._source_info[source_id].name = name
        else:
            logger.warning(f"Fuente {source_id} no existe para establecer nombre")
    
    def get_source_names(self) -> Dict[int, str]:
        """Compatibilidad: obtener nombres de fuentes"""
        return {sid: info.name for sid, info in self._source_info.items() if info.name}

    def get_deformer(self, macro_id: Optional[str] = None) -> CompositeDeformer:
        """
        Obtener deformador para un macro o el global
        
        Parameters
        ----------
        macro_id : str, optional
            ID del macro. Si None, retorna el deformador global
            
        Returns
        -------
        CompositeDeformer
            Deformador solicitado
        """
        if macro_id:
            if macro_id not in self._macro_deformers:
                self._macro_deformers[macro_id] = CompositeDeformer()
            return self._macro_deformers[macro_id]
        return self.global_deformer

    def save_modulator_state(self, macro_name: str) -> Dict[str, Any]:
        """Guardar estado de los moduladores de un macro"""
        if macro_name not in self._macros:
            logger.error(f"Macro '{macro_name}' no encontrado")
            return {}
            
        macro = self._macros[macro_name]
        state = {}
        
        for sid in macro.source_ids:
            if sid in self.orientation_modulators:
                state[sid] = self.orientation_modulators[sid].get_state_dict()
                
        logger.info(f"Estado de moduladores guardado para macro '{macro_name}'")
        return state

    def load_modulator_state(self, macro_name: str, state: Dict[str, Any]) -> bool:
        """Cargar estado de los moduladores de un macro"""
        if macro_name not in self._macros:
            logger.error(f"Macro '{macro_name}' no encontrado")
            return False
            
        macro = self._macros[macro_name]
        
        for sid, mod_state in state.items():
            sid = int(sid)  # Asegurar que es int
            if sid not in macro.source_ids:
                continue
                
            if sid not in self.orientation_modulators:
                self.create_orientation_modulator(sid)
                
            self.orientation_modulators[sid].load_state_dict(mod_state)
            
        logger.info(f"Estado de moduladores cargado para macro '{macro_name}'")
        return True

    def _send_osc_update(self):
        """Enviar actualización OSC incluyendo orientaciones"""
        if not hasattr(self, 'osc_bridge') or not self.osc_bridge:
            return
            
        positions = []
        orientations = []
        apertures = []
        names = {}
        
        # Recopilar datos de todas las fuentes activas
        active_sources = sorted(self._source_motions.keys())
        
        for sid in active_sources:
            # Posiciones
            positions.append(self._positions[sid])
            
            # Orientaciones y aperturas
            if self.enable_modulator and sid in self.orientation_modulators:
                orientations.append(self._orientations[sid])
                apertures.append(self._apertures[sid])
            else:
                orientations.append([0.0, 0.0, 0.0])
                apertures.append(0.5)
                
            # Nombres
            if sid in self._source_info and self._source_info[sid].name:
                names[sid] = self._source_info[sid].name
        
        # Enviar todo
        if positions:
            self.osc_bridge.send_full_state(
                positions=np.array(positions),
                orientations=np.array(orientations),
                apertures=np.array(apertures),
                names=names
            )

    def _check_rate_limit(self) -> bool:
        """Verificar si se debe enviar actualización OSC (para limitar tasa)"""
        # Simple implementación: siempre enviar
        # Puedes implementar un limitador más sofisticado si es necesario
        return True

    def _get_macro_source_ids(self, macro: EnhancedMacroSource) -> List[int]:
        """Obtener IDs de fuentes de un macro (helper para compatibilidad)"""
        return list(macro.source_ids)

    def stop(self):
        """Detener el motor"""
        self._is_running = False
        logger.info("Motor detenido")

    def __del__(self):
        """Limpieza al destruir"""
        self.stop()        