"""Módulo del sistema de trayectorias"""
